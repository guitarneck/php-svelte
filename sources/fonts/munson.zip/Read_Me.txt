This archive contains the Munson font.

If you only want to use this font on your computer you only need the .OTF files.

If you want to use Munson on a website you will need the .WOFF files in the Webfonts folder.

If you want to edit the font and/or create your own version then you will need the .FCP files in the 'Source Code' folder.  You will need a copy of High Logic Font Creator to open these files.

Under the terms of the SIL open font license you cannot sell this font and if you create your own version of this font you must choose a new name for it.
